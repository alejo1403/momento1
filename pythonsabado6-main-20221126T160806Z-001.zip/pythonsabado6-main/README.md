# pythonsabado6 Alejandro Jimenez Rivera
### solucion de actividad 
